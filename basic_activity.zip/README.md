# Basic Activity

Starter activity with basic UI

Java and Kotlin starter sources are included.
