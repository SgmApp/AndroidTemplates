# Bottom Navigation Activity

Bottom navigation starter

Java and Kotlin starter sources are included.
