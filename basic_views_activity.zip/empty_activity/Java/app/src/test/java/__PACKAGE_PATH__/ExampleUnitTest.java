package __PACKAGE_NAME__;

import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertTrue(true);
    }
}
