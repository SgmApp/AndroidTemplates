package __PACKAGE_NAME__

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.Assert.assertTrue

@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {
    @Test
    fun app_isCorrect() {
        assertTrue(true)
    }
}
