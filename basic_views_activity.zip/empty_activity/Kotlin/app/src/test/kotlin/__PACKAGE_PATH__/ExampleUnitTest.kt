package __PACKAGE_NAME__

import org.junit.Test
import org.junit.Assert.assertTrue

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertTrue(true)
    }
}
