package __PACKAGE_NAME__;
public class ExampleUnitTest {}
