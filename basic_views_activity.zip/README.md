# Basic Views Activity

Android Views starter

Java and Kotlin starter sources are included.
