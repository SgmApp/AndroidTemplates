# Empty Activity

Simple Android activity

Java and Kotlin starter sources are included.
