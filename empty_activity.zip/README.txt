Java and Kotlin variants are separated. Select the matching folder.
